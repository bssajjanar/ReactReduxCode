import React from 'react'

export default function Products() {
  return <div>Capgemini Products</div>
}
