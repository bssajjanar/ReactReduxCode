import React from 'react'

export default function AboutUs() {
  return <div>About Capgemini</div>
}
