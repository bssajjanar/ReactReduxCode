import React from 'react'
import { Link, browserHistory } from 'react-router'

export default function App({ children }) {
  return (
    <div>
      <header>       
        {' '}
        <Link to="/">Home</Link>
        {' '}
        <Link to="/about">About Us</Link>
        {' '}
        <Link to="/Products">Products</Link>
		 {' '}
        <Link to="/contactus">Contact Us</Link>
      </header>
      <div>
        Welcome to Capgemini!!
      </div>
     <div style={{ marginTop: '1.5em' }}>{children}</div>
    </div>
  )
}
